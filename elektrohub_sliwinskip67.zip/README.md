# elektrohub (sliwinskip67) – paczka z panelem /admin

Masz DWIE konfiguracje panelu Netlify CMS:

## A) DOMYŚLNIE: `admin/config.yml` (backend: git-gateway) – NAJPROŚCIEJ
Działa na Netlify bez stawiania dodatkowego OAuth. Kroki:
1. GitHub → utwórz repo `elektrohub` w koncie `sliwinskip67` i wgraj cały projekt.
2. Netlify → Add new site → Import from Git → wskaż `sliwinskip67/elektrohub`.
3. Netlify → Site configuration → Identity → Enable Identity.
4. Netlify → Identity → Services → Enable Git Gateway.
5. Otwórz `/admin` i zaloguj się (Invite only → wyślij sobie zaproszenie).

## B) ALTERNATYWA: `admin/config.github.yml` (backend: github)
Jeśli wolisz bez Netlify Identity (wymaga ustawień OAuth na GitHubie). Aby użyć:
- Zmień nazwę `admin/config.github.yml` → `admin/config.yml`.
- Skonfiguruj GitHub OAuth App (callback `https://twoja-domena.netlify.app/admin/callback`).

## Gdzie są produkty?
- W `data/products.json` (tablica `items`). Panel po publikacji zapisze zmiany w tym pliku.
